package com.ex9.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ex9.demo.model.Cliente;

public interface ClienteRepository extends JpaRepository<Cliente, Long> { }
